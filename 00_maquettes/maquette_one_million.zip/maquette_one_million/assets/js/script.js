// Test lien HTML et JS //
// alert('ops')

let containerTeam = document.querySelector('#container-team');
let teamMember = document.querySelectorAll('.team');
let ceo = document.querySelector('#ceo');
let cpo = document.querySelector('#cpo');
let communication = document.querySelector('#communication');
let educator = document.querySelector('#educator');

let teamTable = [ceo, cpo, communication, educator];


containerTeam.addEventListener('mouseover', ()=>{

    for (let MouseEvent of teamTable) {

        teamMember.style.background = 'url(assets/img/perso_01.jpg)';
    }
    

})
